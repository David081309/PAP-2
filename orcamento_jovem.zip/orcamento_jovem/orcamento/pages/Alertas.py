from datetime import (
    date,
    datetime,
    timedelta
)

import pandas as pd
import streamlit as st

from db import (
    get_incomes,
    get_expenses,
    get_goals
)

from utils import calculate_summary


# =========================================================
# FUNÇÕES AUXILIARES
# =========================================================

def to_date(value):
    if (
        value is None
        or pd.isna(value)
    ):
        return None

    if isinstance(
        value,
        datetime
    ):
        return value.date()

    if isinstance(
        value,
        date
    ):
        return value

    try:
        return date.fromisoformat(
            str(value)[:10]
        )

    except ValueError:
        return None


# =========================================================
# GERAR ALERTAS
# =========================================================

def generate_alerts(
    total_incomes,
    total_expenses,
    balance,
    goals_df,
    incomes_df,
    expenses_df
):
    alerts = []

    today = date.today()

    next_seven_days = (
        today
        + timedelta(days=7)
    )


    # -----------------------------------------------------
    # SITUAÇÃO GERAL
    # -----------------------------------------------------

    if (
        total_incomes <= 0
        and total_expenses > 0
    ):
        alerts.append({
            "type": "error",
            "icon": "🚨",
            "message": (
                "Tens despesas registadas, mas "
                "não existem receitas. Confirma se "
                "falta registar algum vencimento."
            )
        })


    if balance < 0:
        alerts.append({
            "type": "error",
            "icon": "📉",
            "message": (
                f"O saldo está negativo em "
                f"{abs(balance):.2f}€. "
                f"Revê primeiro despesas impulsivas "
                f"e opcionais."
            )
        })

    elif total_incomes > 0:
        margin_percentage = (
            balance
            / total_incomes
        ) * 100

        if (
            margin_percentage >= 0
            and margin_percentage < 10
        ):
            alerts.append({
                "type": "warning",
                "icon": "⚠️",
                "message": (
                    f"A margem disponível é apenas "
                    f"{margin_percentage:.1f}% das "
                    f"receitas. Existe pouca folga "
                    f"para imprevistos."
                )
            })


    if total_incomes > 0:
        expense_percentage = (
            total_expenses
            / total_incomes
        ) * 100

        if expense_percentage >= 90:
            alerts.append({
                "type": "warning",
                "icon": "🧾",
                "message": (
                    f"As despesas representam "
                    f"{expense_percentage:.0f}% "
                    f"das receitas."
                )
            })


    # -----------------------------------------------------
    # DESPESAS
    # -----------------------------------------------------

    if (
        expenses_df is not None
        and not expenses_df.empty
    ):
        expenses = expenses_df.copy()

        expenses["amount"] = pd.to_numeric(
            expenses["amount"],
            errors="coerce"
        ).fillna(0.0)


        # Despesas impulsivas

        impulsive = expenses[
            expenses["kind"]
            .astype(str)
            .str.casefold()
            == "impulsiva".casefold()
        ]

        impulsive_total = float(
            impulsive["amount"].sum()
        )

        if impulsive_total > 0:
            if total_expenses > 0:
                impulsive_share = (
                    impulsive_total
                    / total_expenses
                ) * 100
            else:
                impulsive_share = 0.0

            if (
                impulsive_share >= 15
                or impulsive_total >= 50
            ):
                alerts.append({
                    "type": "warning",
                    "icon": "🛍️",
                    "message": (
                        f"Tens {impulsive_total:.2f}€ "
                        f"em despesas impulsivas "
                        f"({impulsive_share:.0f}% "
                        f"das despesas). Este pode ser "
                        f"o primeiro ponto a rever."
                    )
                })


        # Categoria com maior peso

        category_totals = (
            expenses
            .groupby("category")["amount"]
            .sum()
            .sort_values(
                ascending=False
            )
        )

        if (
            not category_totals.empty
            and total_expenses > 0
        ):
            top_category = str(
                category_totals.index[0]
            )

            top_amount = float(
                category_totals.iloc[0]
            )

            top_share = (
                top_amount
                / total_expenses
            ) * 100

            if top_share >= 40:
                alerts.append({
                    "type": "info",
                    "icon": "📊",
                    "message": (
                        f"A categoria "
                        f"«{top_category}» representa "
                        f"{top_share:.0f}% das despesas. "
                        f"Confirma se este peso é esperado."
                    )
                })


        # Despesas recorrentes próximas

        if "is_recurring" in expenses.columns:
            recurring_expenses = expenses[
                pd.to_numeric(
                    expenses["is_recurring"],
                    errors="coerce"
                ).fillna(0).astype(int) == 1
            ]

            for _, row in (
                recurring_expenses.iterrows()
            ):
                next_date = to_date(
                    row.get("next_date")
                )

                if next_date is None:
                    continue

                if next_date < today:
                    alerts.append({
                        "type": "error",
                        "icon": "⏰",
                        "message": (
                            f"A despesa recorrente "
                            f"«{row['description']}» "
                            f"tem uma data pendente: "
                            f"{next_date}."
                        )
                    })

                elif (
                    today
                    <= next_date
                    <= next_seven_days
                ):
                    alerts.append({
                        "type": "info",
                        "icon": "📅",
                        "message": (
                            f"A despesa "
                            f"«{row['description']}» "
                            f"repete-se em {next_date} "
                            f"({float(row['amount']):.2f}€)."
                        )
                    })


    # -----------------------------------------------------
    # RECEITAS E VENCIMENTOS RECORRENTES
    # -----------------------------------------------------

    if (
        incomes_df is not None
        and not incomes_df.empty
        and "is_recurring" in incomes_df.columns
    ):
        incomes = incomes_df.copy()

        recurring_incomes = incomes[
            pd.to_numeric(
                incomes["is_recurring"],
                errors="coerce"
            ).fillna(0).astype(int) == 1
        ]

        for _, row in (
            recurring_incomes.iterrows()
        ):
            next_date = to_date(
                row.get("next_date")
            )

            if next_date is None:
                continue

            if next_date < today:
                alerts.append({
                    "type": "warning",
                    "icon": "⏰",
                    "message": (
                        f"O vencimento recorrente "
                        f"«{row['description']}» "
                        f"tem uma data pendente: "
                        f"{next_date}."
                    )
                })

            elif (
                today
                <= next_date
                <= next_seven_days
            ):
                alerts.append({
                    "type": "success",
                    "icon": "💶",
                    "message": (
                        f"O vencimento "
                        f"«{row['description']}» "
                        f"está previsto para "
                        f"{next_date} "
                        f"({float(row['amount']):.2f}€)."
                    )
                })


    # -----------------------------------------------------
    # METAS
    # -----------------------------------------------------

    if (
        goals_df is not None
        and not goals_df.empty
    ):
        for _, goal in (
            goals_df.iterrows()
        ):
            target = float(
                goal.get(
                    "target_amount",
                    0
                ) or 0
            )

            saved = float(
                goal.get(
                    "saved_amount",
                    0
                ) or 0
            )

            if target <= 0:
                continue

            progress = (
                saved / target
            )

            deadline = to_date(
                goal.get("deadline")
            )

            remaining = max(
                0.0,
                target - saved
            )

            if progress >= 1:
                alerts.append({
                    "type": "success",
                    "icon": "🎉",
                    "message": (
                        f"A meta "
                        f"«{goal['title']}» "
                        f"está concluída."
                    )
                })

            elif deadline is not None:
                days_left = (
                    deadline - today
                ).days

                if days_left < 0:
                    alerts.append({
                        "type": "error",
                        "icon": "🎯",
                        "message": (
                            f"O prazo da meta "
                            f"«{goal['title']}» terminou "
                            f"e ainda faltam "
                            f"{remaining:.2f}€."
                        )
                    })

                elif days_left <= 30:
                    alerts.append({
                        "type": "warning",
                        "icon": "🎯",
                        "message": (
                            f"Faltam {days_left} dia(s) "
                            f"para a meta "
                            f"«{goal['title']}» e ainda "
                            f"faltam {remaining:.2f}€."
                        )
                    })

            if progress < 0.25:
                alerts.append({
                    "type": "info",
                    "icon": "🌱",
                    "message": (
                        f"A meta "
                        f"«{goal['title']}» está em "
                        f"{progress * 100:.0f}%. "
                        f"Define uma contribuição "
                        f"regular realista."
                    )
                })

    return alerts


# =========================================================
# OBTER ALERTAS DO UTILIZADOR
# =========================================================

def get_user_alerts(user_id):
    incomes_df = get_incomes(
        user_id
    )

    expenses_df = get_expenses(
        user_id
    )

    goals_df = get_goals(
        user_id
    )

    (
        total_incomes,
        total_expenses,
        balance
    ) = calculate_summary(
        incomes_df,
        expenses_df
    )

    return generate_alerts(
        total_incomes,
        total_expenses,
        balance,
        goals_df,
        incomes_df,
        expenses_df
    )


# =========================================================
# SINO DAS NOTIFICAÇÕES
# =========================================================

def notification_bell(user_id):
    alerts = get_user_alerts(
        user_id
    )

    alert_count = len(
        alerts
    )

    if alert_count > 0:
        bell_label = (
            f"🔔 {alert_count}"
        )
    else:
        bell_label = "🔔"

    with st.popover(
        bell_label,
        help="Ver notificações"
    ):
        st.markdown(
            "### Notificações"
        )

        if not alerts:
            st.success(
                "Não existem alertas neste momento."
            )

        else:
            for alert in alerts:
                message = (
                    f"{alert['icon']} "
                    f"{alert['message']}"
                )

                if alert["type"] == "error":
                    st.error(message)

                elif alert["type"] == "warning":
                    st.warning(message)

                elif alert["type"] == "success":
                    st.success(message)

                else:
                    st.info(message)


# =========================================================
# CABEÇALHO DAS PÁGINAS
# =========================================================

def page_header(
    title,
    user_id,
    subtitle=None
):
    title_col, bell_col = st.columns(
        [8, 1],
        vertical_alignment="center"
    )

    with title_col:
        st.title(title)

        if subtitle:
            st.caption(subtitle)

    with bell_col:
        notification_bell(
            user_id
        )