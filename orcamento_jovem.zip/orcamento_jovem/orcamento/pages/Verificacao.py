import streamlit as st

from db import verify_user_token


st.set_page_config(
    page_title="Verificação de Conta",
    page_icon="✅",
    layout="centered"
)


st.title("✅ Verificação de conta")

st.write(
    "Introduz o email e o token que recebeste para ativar a tua conta."
)


default_email = st.session_state.get(
    "pending_verification_email",
    ""
)


with st.form("verify_form"):
    email = st.text_input(
        "Email",
        value=default_email
    )

    token = st.text_input(
        "Token de verificação"
    )

    submit = st.form_submit_button(
        "Verificar conta",
        use_container_width=True
    )

    if submit:
        if email.strip() == "" or token.strip() == "":
            st.warning(
                "Preenche o email e o token."
            )

        else:
            success, message = verify_user_token(
                email.strip(),
                token.strip()
            )

            if success:
                if "pending_verification_email" in st.session_state:
                    del st.session_state["pending_verification_email"]

                st.session_state.account_verified = True
                st.session_state.verification_message = message

                st.rerun()

            else:
                st.error(message)


if st.session_state.get("account_verified", False):
    st.success(
        st.session_state.get(
            "verification_message",
            "Conta verificada com sucesso. Já podes iniciar sessão."
        )
    )

    if st.button(
        "Ir para o login",
        use_container_width=True
    ):
        st.session_state.account_verified = False

        if "verification_message" in st.session_state:
            del st.session_state["verification_message"]

        st.switch_page("app.py")


st.divider()


if st.button(
    "Voltar ao login",
    use_container_width=True
):
    st.switch_page("app.py")