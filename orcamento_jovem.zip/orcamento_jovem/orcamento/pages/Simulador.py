import math

import pandas as pd
import streamlit as st

from auth import (
    require_login,
    sidebar_user
)

from db import (
    get_incomes,
    get_expenses,
    get_goals
)

from utils import calculate_summary

from pages.Alertas import page_header


SOURCE_BUDGET = (
    "https://clientebancario.bportugal.pt/"
    "pt-pt/como-elaborar-um-orcamento-familiar"
)

SOURCE_BALANCE = (
    "https://www.todoscontam.pt/pt-pt/"
    "saldo-entre-rendimentos-e-despesas"
)

SOURCE_GOALS = (
    "https://www.todoscontam.pt/pt-pt/"
    "definir-objetivos"
)


# =========================================================
# FUNÇÕES
# =========================================================

def simulate_cut(
    current_expenses,
    cut_amount
):
    return (
        float(current_expenses)
        - float(cut_amount)
    )


def months_to_goal(
    saved_amount,
    target_amount,
    monthly_contribution
):
    remaining = max(
        0.0,
        float(target_amount)
        - float(saved_amount)
    )

    if monthly_contribution <= 0:
        return None

    if remaining == 0:
        return 0

    return math.ceil(
        remaining
        / float(monthly_contribution)
    )


def prepare_expenses(expenses_df):
    if (
        expenses_df is None
        or expenses_df.empty
    ):
        return pd.DataFrame(
            columns=[
                "description",
                "category",
                "kind",
                "amount",
                "is_recurring"
            ]
        )

    data = expenses_df.copy()

    data["amount"] = pd.to_numeric(
        data["amount"],
        errors="coerce"
    ).fillna(0.0)

    return data


def build_cut_plan(
    expenses_df,
    cut_amount
):
    """
    Procura primeiro despesas impulsivas,
    depois opcionais e, por último,
    despesas necessárias.
    """

    data = prepare_expenses(
        expenses_df
    )

    remaining_cut = float(
        cut_amount
    )

    suggestions = []

    priorities = [
        (
            "Impulsiva",
            "impulsivas"
        ),
        (
            "Opcional",
            "opcionais"
        ),
        (
            "Necessária",
            "necessárias"
        )
    ]

    for (
        kind_value,
        kind_label
    ) in priorities:

        if remaining_cut <= 0:
            break

        subset = data[
            data["kind"]
            .astype(str)
            .str.casefold()
            == kind_value.casefold()
        ].sort_values(
            "amount",
            ascending=False
        )

        available = float(
            subset["amount"].sum()
        )

        if available <= 0:
            continue

        suggested_cut = min(
            available,
            remaining_cut
        )

        examples = [
            str(value)
            for value in (
                subset["description"]
                .head(3)
                .tolist()
            )
        ]

        suggestions.append({
            "kind": kind_value,
            "label": kind_label,
            "available": available,
            "suggested_cut": suggested_cut,
            "examples": examples
        })

        remaining_cut -= suggested_cut

    return (
        suggestions,
        max(
            0.0,
            remaining_cut
        )
    )


def show_specific_cut_advice(
    expenses_df,
    cut_amount,
    current_balance,
    new_balance
):
    suggestions, uncovered = (
        build_cut_plan(
            expenses_df,
            cut_amount
        )
    )

    st.markdown(
        "### Sugestão prática"
    )

    if not suggestions:
        st.info(
            "Não existem despesas classificadas "
            "suficientes para indicar onde aplicar "
            "o corte. Confirma a classificação dos "
            "registos."
        )

        return

    for suggestion in suggestions:
        examples_text = (
            ", ".join(
                suggestion["examples"]
            )
            if suggestion["examples"]
            else "sem exemplos disponíveis"
        )

        if suggestion["kind"] == "Impulsiva":
            st.warning(
                f"Começa por rever as despesas "
                f"impulsivas. Tens "
                f"{suggestion['available']:.2f}€ "
                f"registados neste tipo e poderias "
                f"procurar reduzir até "
                f"{suggestion['suggested_cut']:.2f}€. "
                f"Exemplos: {examples_text}."
            )

        elif suggestion["kind"] == "Opcional":
            st.info(
                f"Se as despesas impulsivas não forem "
                f"suficientes, analisa as opcionais. "
                f"Poderias procurar reduzir "
                f"{suggestion['suggested_cut']:.2f}€ "
                f"entre registos como "
                f"{examples_text}."
            )

        else:
            st.error(
                f"Para atingir o corte ainda seria "
                f"necessário rever "
                f"{suggestion['suggested_cut']:.2f}€ "
                f"em despesas necessárias. "
                f"Faz esta redução apenas depois de "
                f"confirmar que não afeta alimentação, "
                f"saúde, estudos ou transportes. "
                f"Exemplos: {examples_text}."
            )

    if uncovered > 0:
        st.warning(
            f"Mesmo revendo todas as despesas, "
            f"ainda faltariam {uncovered:.2f}€ "
            f"para atingir o corte pretendido."
        )

    if new_balance < 0:
        st.warning(
            f"Depois do corte, o saldo ainda "
            f"ficaria negativo em "
            f"{abs(new_balance):.2f}€. "
            f"Além de reduzir despesas, poderá "
            f"ser necessário aumentar os rendimentos."
        )

    elif new_balance == 0:
        st.info(
            "O orçamento ficaria equilibrado, "
            "mas sem margem para imprevistos "
            "ou poupança."
        )

    elif current_balance < 0:
        st.success(
            f"O corte permitiria sair de saldo "
            f"negativo e criar uma margem de "
            f"{new_balance:.2f}€."
        )

    else:
        st.success(
            f"A margem passaria para "
            f"{new_balance:.2f}€. "
            f"Considera reservar parte para "
            f"uma meta ou para imprevistos."
        )

    st.caption(
        "Fundamentação: o Banco de Portugal "
        "recomenda distinguir despesas necessárias "
        "e supérfluas, fixas e variáveis. "
        "O Todos Contam recomenda corrigir saldos "
        "negativos reduzindo despesas ou aumentando "
        "rendimentos."
    )

    source_col1, source_col2 = (
        st.columns(2)
    )

    with source_col1:
        st.link_button(
            "Banco de Portugal",
            SOURCE_BUDGET,
            use_container_width=True
        )

    with source_col2:
        st.link_button(
            "Todos Contam",
            SOURCE_BALANCE,
            use_container_width=True
        )


def show_goal_advice(
    monthly_contribution,
    current_balance,
    months
):
    if months == 0:
        st.success(
            "A meta já está concluída."
        )

        return

    if current_balance <= 0:
        st.warning(
            "O saldo atual não apresenta margem "
            "positiva. Antes de assumir esta "
            "contribuição mensal, revê as despesas "
            "e tenta estabilizar o orçamento."
        )

    elif monthly_contribution > current_balance:
        difference = (
            monthly_contribution
            - current_balance
        )

        st.warning(
            f"A contribuição é {difference:.2f}€ "
            f"superior à margem atual. Para a tornar "
            f"mais sustentável, reduz o valor mensal, "
            f"aumenta o prazo ou revê despesas "
            f"ajustáveis."
        )

    else:
        remaining_margin = (
            current_balance
            - monthly_contribution
        )

        st.info(
            f"Depois desta contribuição ainda "
            f"ficaria uma margem estimada de "
            f"{remaining_margin:.2f}€."
        )

    st.caption(
        "Fonte: Todos Contam — a elaboração "
        "do orçamento deve considerar os objetivos "
        "de poupança e o respetivo prazo."
    )

    st.link_button(
        "Consultar fonte",
        SOURCE_GOALS
    )


# =========================================================
# CONFIGURAÇÃO
# =========================================================

st.set_page_config(
    page_title="Simulador",
    page_icon="🧮",
    layout="wide"
)


require_login()
sidebar_user()


user_id = st.session_state.user_id


page_header(
    "🧮 Simulador",
    user_id,
    "Simula diferentes decisões financeiras."
)


# =========================================================
# DADOS
# =========================================================

incomes_df = get_incomes(
    user_id
)

expenses_df = get_expenses(
    user_id
)

goals_df = get_goals(
    user_id
)


total_incomes, total_expenses, balance = (
    calculate_summary(
        incomes_df,
        expenses_df
    )
)


# =========================================================
# SIMULAR CORTE
# =========================================================

st.subheader(
    "Simular corte de despesas"
)


st.write(
    f"Atualmente tens "
    f"**{total_expenses:.2f}€** em despesas "
    f"e um saldo de **{balance:.2f}€**."
)


cut_amount = st.number_input(
    "Quanto queres cortar nas despesas? (€)",
    min_value=0.0,
    format="%.2f"
)


if cut_amount > 0:
    if cut_amount > total_expenses:
        st.error(
            f"Não podes cortar "
            f"{cut_amount:.2f}€, porque as despesas "
            f"registadas totalizam apenas "
            f"{total_expenses:.2f}€."
        )

    else:
        new_expenses = simulate_cut(
            total_expenses,
            cut_amount
        )

        new_balance = (
            total_incomes
            - new_expenses
        )

        st.markdown(
            "### Resultado da simulação"
        )

        col1, col2, col3 = (
            st.columns(3)
        )

        col1.metric(
            "Corte simulado",
            f"{cut_amount:.2f}€"
        )

        col2.metric(
            "Novas despesas",
            f"{new_expenses:.2f}€",
            delta=f"-{cut_amount:.2f}€"
        )

        col3.metric(
            "Novo saldo",
            f"{new_balance:.2f}€",
            delta=(
                f"{new_balance - balance:.2f}€"
            )
        )

        show_specific_cut_advice(
            expenses_df,
            cut_amount,
            balance,
            new_balance
        )


# =========================================================
# SIMULAR META
# =========================================================

st.divider()

st.subheader(
    "Tempo para atingir uma meta"
)


if (
    goals_df is None
    or goals_df.empty
):
    st.info(
        "Não tens metas registadas. "
        "Vai à página de Metas para criar uma."
    )

else:
    goal_options = {
        int(row["id"]): (
            f"{row['title']} — "
            f"{float(row['saved_amount']):.2f}€ "
            f"de "
            f"{float(row['target_amount']):.2f}€"
        )
        for _, row in goals_df.iterrows()
    }

    selected_goal_id = st.selectbox(
        "Escolhe a meta",
        options=list(
            goal_options.keys()
        ),
        format_func=lambda goal_id: (
            goal_options[goal_id]
        )
    )

    goal = goals_df[
        goals_df["id"]
        == selected_goal_id
    ].iloc[0]

    target = float(
        goal["target_amount"]
    )

    saved = float(
        goal["saved_amount"]
    )

    monthly_contribution = st.number_input(
        "Quanto consegues poupar por mês? (€)",
        min_value=0.0,
        format="%.2f"
    )

    if monthly_contribution > 0:
        months = months_to_goal(
            saved,
            target,
            monthly_contribution
        )

        if months is not None:
            st.success(
                f"Com {monthly_contribution:.2f}€ "
                f"por mês, atinges a meta em "
                f"aproximadamente {months} mês(es)."
            )

            show_goal_advice(
                monthly_contribution,
                balance,
                months
            )


st.caption(
    "As simulações têm finalidade educativa "
    "e utilizam os dados registados pelo utilizador. "
    "Não constituem aconselhamento financeiro "
    "profissional."
)