import re

import streamlit as st

from auth import (
    require_login,
    sidebar_user
)

from envio_email import enviar_email

from pages.Alertas import page_header


st.set_page_config(
    page_title="Contactos",
    page_icon="✉️",
    layout="wide"
)


require_login()
sidebar_user()


user_id = st.session_state.user_id
username = st.session_state.username


page_header(
    "✉️ Contactos",
    user_id,
    "Envia uma dúvida, sugestão ou pedido de ajuda."
)


def email_valido(email):
    padrao = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"

    return re.match(
        padrao,
        email
    ) is not None


st.subheader("Enviar mensagem")

with st.form(
    "contact_form",
    clear_on_submit=True
):
    nome = st.text_input(
        "Nome",
        value=username
    )

    email_utilizador = st.text_input(
        "O teu email",
        placeholder="exemplo@email.com"
    )

    assunto = st.text_input(
        "Assunto",
        placeholder="Escreve o assunto da mensagem"
    )

    mensagem = st.text_area(
        "Mensagem",
        placeholder="Escreve aqui a tua mensagem.",
        height=180,
        max_chars=2000
    )

    enviar = st.form_submit_button(
        "Enviar mensagem",
        use_container_width=True
    )

    if enviar:
        nome = nome.strip()
        email_utilizador = email_utilizador.strip()
        assunto = assunto.strip()
        mensagem = mensagem.strip()

        if not nome:
            st.error(
                "O nome é obrigatório."
            )

        elif not email_utilizador:
            st.error(
                "O email é obrigatório."
            )

        elif not email_valido(email_utilizador):
            st.error(
                "Introduz um endereço de email válido."
            )

        elif not assunto:
            st.error(
                "O assunto é obrigatório."
            )

        elif not mensagem:
            st.error(
                "A mensagem é obrigatória."
            )

        else:
            with st.spinner(
                "A enviar o e-mail..."
            ):
                sucesso, resposta = enviar_email(
                    nome,
                    email_utilizador,
                    assunto,
                    mensagem
                )

            if sucesso:
                st.success(resposta)

            else:
                st.error(resposta)


st.divider()

st.info(
    "Não envies passwords, dados bancários "
    "ou outras informações confidenciais."
)