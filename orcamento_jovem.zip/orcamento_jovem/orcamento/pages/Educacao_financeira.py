import streamlit as st

from auth import require_login, sidebar_user
from pages.Alertas import page_header


st.set_page_config(
    page_title="Educação Financeira",
    page_icon="📚",
    layout="wide"
)


require_login()
sidebar_user()


user_id = st.session_state.user_id


page_header(
    "📚 Educação Financeira",
    user_id,
    "Aprende conceitos essenciais para gerir melhor o teu dinheiro."
)


st.write(
    "Nesta página encontras vídeos organizados por temas "
    "para aprenderes mais sobre finanças pessoais."
)


videos_por_tema = {
    "💰 Impostos": [
        {
            "titulo": "Como funciona o imposto sobre mais-valias",
            "descricao": "Explica como funcionam os impostos.",
            "url": "https://youtu.be/v-R-5Xu4Ds0?si=KPmolgfE3-0qbv44"
        },
        {
            "titulo": "IUC 2027: Tudo o que muda no imposto automóvel",
            "descricao": "Fala sobre as novas regras do IUC que virão em 2027.",
            "url": "https://youtu.be/rFZRwAGujx8?si=gCBtuUoPKMfzmgm0"
        },
        {
            "titulo": "Declaração automática do IVA: Quem tem direito?",
            "descricao": "Explica como funciona a declaração automatica do IVA.",
            "url": "https://youtu.be/fTwxxs_Lo98?si=z0RN08sYcjV-K6Mb"
        },
        {
            "titulo": "Novas tabelas de IRS: O que muda no salário a partir de agosto",
            "descricao": "Explica a nova tabela de IRS imposta em agosto de 2025.",
            "url": "https://youtu.be/4ZgLgqRk1oE?si=G5MyiwnmK1KXrZaU"
        },
        {
            "titulo": "IRS: Como consultar declarações de anos anteriores",
            "descricao": "Explica como consultar as declarações anteriores do IRS",
            "url": "https://youtu.be/ICjV72zAUF0?si=g9iln1Zm7jP8QdwV"
        },
        {
            "titulo": "Como declarar as mais-valias de investimentos no IRS",
            "descricao": "Fala sobre as mais-valias dos investimentos imobiliarios.",
            "url": "https://youtu.be/ICjV72zAUF0?si=0fKAP6LUxa3g81DQ"
        },
        {
            "titulo": "IMI: Como consultar e confirmar o valor a pagar",
            "descricao": "Explica como consultar o valor a pagar no IMI",
            "url": "https://youtu.be/5cngAktleY0?si=9ZoqcMpqRPAm9RWV"
        },
        {
            "titulo": "Passa recibos? Há novidades sobre o regime de isenção do IVA",
            "descricao": "Fala sobre uma mudança nos recibos verdes",
            "url": "https://youtu.be/1GAmYF418eA?si=5zpw9RUn85ZHIpHK"
        },
        {
            "titulo": "De A a J: Questões sobre os anexos da declaração de IRS",
            "descricao": "Explica duvidas frequentes sobre a declaração do IRS",
            "url": "https://youtu.be/0nG2Jpl3ynI?si=H24onMtXTeY5z8CJ"
        },
        {
            "titulo": "Quero arrendar a minha casa",
            "descricao": "Explica como as pessoas podem arrendar a sua casa",
            "url": "https://youtu.be/_RFkkhLmgic?si=-pgAyX22jRHXa-Rx"
        },
        {
            "titulo": "IRS: Como comunicar o agregado familiar",
            "descricao": "Explica como fazer alterações no agregado familiar.",
            "url": "https://youtu.be/xHEMZJ0qre8?si=558b7K6Ahtxc4x9h"
        },
        {
            "titulo": "Como preencher a declaração de IVA?",
            "descricao": "Explica como preencher a declaração periodica do IVA",
            "url": "https://youtu.be/gPESKeIoTxM?si=orBk5rx2Tb3LDg-b"
        },
        {
            "titulo": "IMI: Saiba quanto vai pagar este ano",
            "descricao": "Explica como consultar a taxa do munincipio e fazer as contas do IMI",
            "url": "https://youtu.be/NizRVyGzYuI?si=i7Dtp-6VOyHBul4E"
        },
        {
            "titulo": "Faturas de dependentes e IRS: Como funciona",
            "descricao": "Explica como funcionam os impostos.",
            "url": "https://youtu.be/mT7YCn3W0S4?si=u19eGTfT17FwJOi4"
        },
    ]
}


for tema, videos in videos_por_tema.items():
    with st.expander(tema, expanded=False):
        for video in videos:
            st.markdown(f"### {video['titulo']}")
            st.caption(video["descricao"])

            st.video(video["url"])

            st.divider()