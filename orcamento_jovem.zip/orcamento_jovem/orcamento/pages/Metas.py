from datetime import date

import streamlit as st

from auth import require_login, sidebar_user

from db import (
    add_goal,
    get_goals,
    update_goal_saved_amount,
    delete_goal
)

from pages.Alertas import page_header


st.set_page_config(
    page_title="Metas",
    page_icon="🎯",
    layout="wide"
)

require_login()
sidebar_user()

user_id = st.session_state.user_id
username = st.session_state.username

page_header(
    "🎯 Metas de Poupança",
    user_id,
    "Cria, acompanha e atualiza o valor poupado das tuas metas."
)

st.caption(
    f"Utilizador autenticado: {username}"
)

st.markdown("## Criar nova meta")

with st.form(
    "goal_form",
    clear_on_submit=True
):
    title = st.text_input(
        "Nome da meta"
    )

    target_amount = st.number_input(
        "Valor objetivo (€)",
        min_value=0.0,
        format="%.2f"
    )

    saved_amount = st.number_input(
        "Valor já poupado (€)",
        min_value=0.0,
        format="%.2f"
    )

    deadline = st.date_input(
        "Prazo da meta",
        value=date.today()
    )

    submitted = st.form_submit_button(
        "Guardar meta",
        use_container_width=True
    )

    if submitted:
        if not title.strip():
            st.error(
                "O nome da meta é obrigatório."
            )

        elif target_amount <= 0:
            st.error(
                "O objetivo tem de ser superior a zero."
            )

        elif saved_amount > target_amount:
            st.error(
                "O valor poupado não pode ultrapassar o objetivo."
            )

        else:
            add_goal(
                user_id,
                title.strip(),
                target_amount,
                saved_amount,
                str(deadline)
            )

            st.success(
                "Meta adicionada com sucesso."
            )

            st.rerun()


st.divider()
st.markdown("## Metas registadas")

goals_df = get_goals(
    user_id
)

if goals_df.empty:
    st.info(
        "Ainda não tens metas registadas."
    )

else:
    for _, goal in goals_df.iterrows():
        goal_id = int(
            goal["id"]
        )

        title = str(
            goal["title"]
        )

        target = float(
            goal["target_amount"]
        )

        saved = float(
            goal["saved_amount"]
        )

        remaining = max(
            0.0,
            target - saved
        )

        progress = (
            0.0
            if target <= 0
            else min(
                saved / target,
                1.0
            )
        )

        with st.expander(
            f"{title} — {progress * 100:.0f}%"
        ):
            col1, col2, col3 = (
                st.columns(3)
            )

            col1.metric(
                "Objetivo",
                f"{target:.2f}€"
            )

            col2.metric(
                "Poupado",
                f"{saved:.2f}€"
            )

            col3.metric(
                "Em falta",
                f"{remaining:.2f}€"
            )

            st.progress(progress)

            st.write(
                f"**Prazo:** {goal['deadline']}"
            )

            with st.container(border=True):
                st.markdown("**Atualizar valor poupado**")

                st.caption(
                    f"Podes adicionar no máximo {remaining:.2f}€ "
                    f"e retirar no máximo {saved:.2f}€."
                )

                col_add, col_remove = st.columns(2)

                # ─────────────────────────────────────────
                # ADICIONAR VALOR
                # ─────────────────────────────────────────

                with col_add:
                    st.markdown("### Adicionar")

                    with st.form(f"add_goal_amount_form_{goal_id}"):

                        amount_to_add = st.number_input(
                            "Valor a adicionar (€)",
                            min_value=0.0,
                            value=0.0,
                            step=1.0,
                            format="%.2f",
                            key=f"amount_to_add_{goal_id}"
                        )

                        add_submit = st.form_submit_button(
                            "Adicionar valor",
                            use_container_width=True
                        )

                        if add_submit:

                            if amount_to_add <= 0:
                                st.warning(
                                    "Indica um valor superior a zero."
                                )

                            elif amount_to_add > remaining:
                                st.error(
                                    f"Não podes adicionar {amount_to_add:.2f}€. "
                                    f"O máximo que podes adicionar é "
                                    f"{remaining:.2f}€."
                                )

                            else:
                                success, message = update_goal_saved_amount(
                                    user_id,
                                    goal_id,
                                    amount_to_add
                                )

                                if success:
                                    st.success(message)
                                    st.rerun()

                                else:
                                    st.error(message)

                # ─────────────────────────────────────────
                # RETIRAR VALOR
                # ─────────────────────────────────────────

                with col_remove:
                    st.markdown("### Retirar")

                    with st.form(f"remove_goal_amount_form_{goal_id}"):

                        amount_to_remove = st.number_input(
                            "Valor a retirar (€)",
                            min_value=0.0,
                            value=0.0,
                            step=1.0,
                            format="%.2f",
                            key=f"amount_to_remove_{goal_id}"
                        )

                        remove_submit = st.form_submit_button(
                            "Retirar valor",
                            use_container_width=True
                        )

                        if remove_submit:

                            if amount_to_remove <= 0:
                                st.warning(
                                    "Indica um valor superior a zero."
                                )

                            elif amount_to_remove > saved:
                                st.error(
                                    f"Não podes retirar {amount_to_remove:.2f}€. "
                                    f"O máximo que podes retirar é "
                                    f"{saved:.2f}€."
                                )

                            else:
                                success, message = update_goal_saved_amount(
                                    user_id,
                                    goal_id,
                                    -amount_to_remove
                                )

                                if success:
                                    st.success(message)
                                    st.rerun()

                                else:
                                    st.error(message)
            

            st.divider()

            with st.container(border=True):
                st.markdown("**Eliminar meta**")

                st.warning(
                    "Esta ação elimina a meta definitivamente."
                )

                confirm_delete = st.checkbox(
                    "Confirmo que quero eliminar esta meta",
                    key=f"confirm_delete_goal_{goal_id}"
                )

                if st.button(
                    "Eliminar meta",
                    key=f"delete_goal_button_{goal_id}",
                    use_container_width=True
                ):
                    if not confirm_delete:
                        st.error(
                            "Tens de confirmar antes de eliminar a meta."
                        )

                    else:
                        deleted = delete_goal(
                            goal_id,
                            user_id
                        )

                        if deleted:
                            st.success(
                                "Meta eliminada com sucesso."
                            )

                            st.rerun()

                        else:
                            st.error(
                                "Não foi possível eliminar a meta."
                            )