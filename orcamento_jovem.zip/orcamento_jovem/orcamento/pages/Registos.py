from datetime import date

import streamlit as st

from auth import require_login, sidebar_user

from db import (
    add_income,
    get_incomes,
    delete_income,
    add_expense,
    get_expenses,
    delete_expense
)

from utils import (
    ALL_CATEGORIES,
    EXPENSE_KINDS,
    FREQUENCIES
)

from pages.Alertas import page_header


st.set_page_config(
    page_title="Registos",
    page_icon="💸",
    layout="wide"
)

require_login()
sidebar_user()

user_id = st.session_state.user_id

page_header(
    "💸 Registos Financeiros",
    user_id,
    "Regista receitas e despesas pontuais ou recorrentes."
)

tab1, tab2, tab3 = st.tabs([
    "Receitas",
    "Despesas",
    "Histórico"
])


# ─────────────────────────────────────────────
# RECEITAS
# ─────────────────────────────────────────────

with tab1:
    st.subheader(
        "Adicionar receita ou vencimento"
    )

    income_recurring = st.checkbox(
        "É uma receita recorrente?",
        key="income_recurring_check"
    )

    with st.form(
        "income_form",
        clear_on_submit=True
    ):
        description = st.text_input(
            "Descrição da receita"
        )

        amount = st.number_input(
            "Valor (€)",
            min_value=0.0,
            format="%.2f",
            key="income_amount"
        )

        income_date = st.date_input(
            "Data do primeiro recebimento",
            value=date.today(),
            key="income_date"
        )

        frequency = None

        if income_recurring:
            frequency = st.selectbox(
                "Frequência",
                FREQUENCIES
            )

            st.caption(
                "A próxima data será calculada automaticamente."
            )

        submit = st.form_submit_button(
            "Guardar receita",
            use_container_width=True
        )

        if submit:
            if not description.strip():
                st.error(
                    "A descrição é obrigatória."
                )

            elif amount <= 0:
                st.error(
                    "O valor tem de ser superior a zero."
                )

            else:
                add_income(
                    user_id=user_id,
                    description=description.strip(),
                    amount=float(amount),
                    income_date=str(income_date),
                    is_recurring=int(
                        income_recurring
                    ),
                    frequency=frequency
                )

                st.success(
                    "Receita adicionada com sucesso."
                )

                st.rerun()


# ─────────────────────────────────────────────
# DESPESAS
# ─────────────────────────────────────────────

with tab2:
    st.subheader(
        "Adicionar despesa"
    )

    expense_recurring = st.checkbox(
        "É uma despesa recorrente?",
        key="expense_recurring_check"
    )

    with st.form(
        "expense_form",
        clear_on_submit=True
    ):
        description = st.text_input(
            "Descrição da despesa"
        )

        category = st.selectbox(
            "Categoria",
            ALL_CATEGORIES
        )

        kind = st.selectbox(
            "Tipo de despesa",
            EXPENSE_KINDS
        )

        amount = st.number_input(
            "Valor (€)",
            min_value=0.0,
            format="%.2f",
            key="expense_amount"
        )

        expense_date = st.date_input(
            "Data do primeiro pagamento",
            value=date.today(),
            key="expense_date"
        )

        frequency = None

        if expense_recurring:
            frequency = st.selectbox(
                "Frequência",
                FREQUENCIES
            )

            st.caption(
                "A próxima data será calculada automaticamente."
            )

        submit = st.form_submit_button(
            "Guardar despesa",
            use_container_width=True
        )

        if submit:
            if not description.strip():
                st.error(
                    "A descrição é obrigatória."
                )

            elif amount <= 0:
                st.error(
                    "O valor tem de ser superior a zero."
                )

            else:
                add_expense(
                    user_id=user_id,
                    description=description.strip(),
                    category=category,
                    kind=kind,
                    amount=float(amount),
                    expense_date=str(expense_date),
                    is_recurring=int(
                        expense_recurring
                    ),
                    frequency=frequency
                )

                st.success(
                    "Despesa adicionada com sucesso."
                )

                st.rerun()


# ─────────────────────────────────────────────
# HISTÓRICO
# ─────────────────────────────────────────────

with tab3:
    st.subheader(
        "Histórico financeiro"
    )

    incomes_df = get_incomes(
        user_id
    )

    expenses_df = get_expenses(
        user_id
    )

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### Receitas")

        if incomes_df.empty:
            st.info(
                "Ainda não existem receitas registadas."
            )

        else:
            st.dataframe(
                incomes_df[
                    [
                        "description",
                        "amount",
                        "income_date",
                        "is_recurring",
                        "frequency",
                        "next_date"
                    ]
                ].rename(
                    columns={
                        "description": "Descrição",
                        "amount": "Valor",
                        "income_date": "Data",
                        "is_recurring": "Recorrente",
                        "frequency": "Frequência",
                        "next_date": "Próxima data"
                    }
                ),
                use_container_width=True,
                hide_index=True
            )

            st.markdown(
                "#### Eliminar receita ou vencimento"
            )

            income_options = {}

            for _, row in incomes_df.iterrows():
                record_id = int(
                    row["id"]
                )

                income_options[record_id] = (
                    f"{row['description']} — "
                    f"{float(row['amount']):.2f}€ — "
                    f"{row['income_date']}"
                )

            with st.form(
                "delete_income_form"
            ):
                selected_income_id = st.selectbox(
                    "Seleciona a receita",
                    options=list(
                        income_options.keys()
                    ),
                    format_func=lambda record_id: (
                        income_options[record_id]
                    )
                )

                confirm_delete_income = st.checkbox(
                    "Confirmo que quero eliminar esta receita",
                    key="confirm_delete_income"
                )

                delete_submit = (
                    st.form_submit_button(
                        "Eliminar receita",
                        use_container_width=True
                    )
                )

                if delete_submit:
                    if not confirm_delete_income:
                        st.error(
                            "Tens de confirmar antes de eliminar a receita."
                        )

                    else:
                        deleted = delete_income(
                            selected_income_id,
                            user_id
                        )

                        if deleted:
                            st.success(
                                "Receita eliminada com sucesso."
                            )
                            st.rerun()
                        else:
                            st.error(
                                "Não foi possível eliminar a receita."
                            )

    with col2:
        st.markdown("### Despesas")

        if expenses_df.empty:
            st.info(
                "Ainda não existem despesas registadas."
            )

        else:
            st.dataframe(
                expenses_df[
                    [
                        "description",
                        "category",
                        "kind",
                        "amount",
                        "expense_date",
                        "is_recurring",
                        "frequency",
                        "next_date"
                    ]
                ].rename(
                    columns={
                        "description": "Descrição",
                        "category": "Categoria",
                        "kind": "Tipo",
                        "amount": "Valor",
                        "expense_date": "Data",
                        "is_recurring": "Recorrente",
                        "frequency": "Frequência",
                        "next_date": "Próxima data"
                    }
                ),
                use_container_width=True,
                hide_index=True
            )

            st.markdown(
                "#### Eliminar despesa"
            )

            expense_options = {}

            for _, row in expenses_df.iterrows():
                record_id = int(
                    row["id"]
                )

                expense_options[record_id] = (
                    f"{row['description']} — "
                    f"{float(row['amount']):.2f}€ — "
                    f"{row['expense_date']}"
                )

            with st.form(
                "delete_expense_form"
            ):
                selected_expense_id = st.selectbox(
                    "Seleciona a despesa",
                    options=list(
                        expense_options.keys()
                    ),
                    format_func=lambda record_id: (
                        expense_options[record_id]
                    )
                )

                confirm_delete_expense = st.checkbox(
                    "Confirmo que quero eliminar esta despesa",
                    key="confirm_delete_expense"
                )

                delete_submit = (
                    st.form_submit_button(
                        "Eliminar despesa",
                        use_container_width=True
                    )
                )

                if delete_submit:
                    if not confirm_delete_expense:
                        st.error(
                            "Tens de confirmar antes de eliminar a despesa."
                        )

                    else:
                        deleted = delete_expense(
                            selected_expense_id,
                            user_id
                        )

                        if deleted:
                            st.success(
                                "Despesa eliminada com sucesso."
                            )
                            st.rerun()
                        else:
                            st.error(
                                "Não foi possível eliminar a despesa."
                            )