import streamlit as st

from auth import require_login, sidebar_user
from pages.Alertas import page_header


st.set_page_config(
    page_title="Quiz",
    page_icon="📝",
    layout="wide"
)


require_login()
sidebar_user()


user_id = st.session_state.user_id


page_header(
    "📝 Quiz",
    user_id,
    "Testa os teus conhecimentos de educação financeira por tema."
)


st.write(
    "Nesta página encontras quizzes organizados por temas. "
    "Cada quiz está relacionado com os conteúdos apresentados na página de Educação Financeira."
)


quizzes_por_tema = {
    "💰 Impostos": [
        {
            "pergunta": "O que são mais-valias?",
            "opcoes": [
                "São despesas mensais obrigatórias.",
                "São ganhos obtidos quando se vende um bem ou investimento por um valor superior ao valor de compra.",
                "São descontos feitos automaticamente no salário.",
                "São multas aplicadas por atraso no pagamento de impostos."
            ],
            "resposta": "São ganhos obtidos quando se vende um bem ou investimento por um valor superior ao valor de compra.",
            "explicacao": "As mais-valias correspondem, de forma geral, ao ganho obtido numa venda, por exemplo de um imóvel ou de um investimento."
        },
        {
            "pergunta": "Porque é importante declarar mais-valias no IRS?",
            "opcoes": [
                "Porque podem ser consideradas rendimentos sujeitos a tributação.",
                "Porque servem para aumentar automaticamente o salário.",
                "Porque substituem a declaração de IVA.",
                "Porque eliminam todas as despesas do contribuinte."
            ],
            "resposta": "Porque podem ser consideradas rendimentos sujeitos a tributação.",
            "explicacao": "Algumas mais-valias podem ter de ser declaradas no IRS, dependendo do tipo de rendimento e das regras fiscais aplicáveis."
        },
        {
            "pergunta": "O que significa IUC?",
            "opcoes": [
                "Imposto Único de Circulação.",
                "Imposto Universal de Crédito.",
                "Imposto Único de Consumo.",
                "Imposto Urbano de Construção."
            ],
            "resposta": "Imposto Único de Circulação.",
            "explicacao": "O IUC é o Imposto Único de Circulação, associado aos veículos."
        },
        {
            "pergunta": "Qual é o objetivo principal do IVA?",
            "opcoes": [
                "Tributar o consumo de bens e serviços.",
                "Tributar apenas os salários.",
                "Substituir o IRS.",
                "Eliminar a necessidade de faturas."
            ],
            "resposta": "Tributar o consumo de bens e serviços.",
            "explicacao": "O IVA é um imposto aplicado ao consumo de bens e serviços."
        },
        {
            "pergunta": "O que significa estar no regime de isenção de IVA?",
            "opcoes": [
                "Significa que nunca é necessário declarar rendimentos.",
                "Significa que, cumprindo certas condições, o trabalhador pode não cobrar IVA nas suas operações.",
                "Significa que o contribuinte deixa de pagar todos os impostos.",
                "Significa que o IRS passa a ser automático."
            ],
            "resposta": "Significa que, cumprindo certas condições, o trabalhador pode não cobrar IVA nas suas operações.",
            "explicacao": "O regime de isenção de IVA pode aplicar-se a alguns trabalhadores independentes ou empresas que cumpram certas condições."
        },
        {
            "pergunta": "Para que serve a declaração periódica de IVA?",
            "opcoes": [
                "Para comunicar à Autoridade Tributária o IVA liquidado e o IVA dedutível num determinado período.",
                "Para pedir uma senha nova do Portal das Finanças.",
                "Para declarar apenas despesas escolares.",
                "Para substituir a declaração de IRS."
            ],
            "resposta": "Para comunicar à Autoridade Tributária o IVA liquidado e o IVA dedutível num determinado período.",
            "explicacao": "A declaração periódica de IVA serve para apurar o IVA a pagar ou a recuperar."
        },
        {
            "pergunta": "O que é o IRS?",
            "opcoes": [
                "Imposto sobre o Rendimento das Pessoas Singulares.",
                "Imposto sobre Receitas Simples.",
                "Imposto Rodoviário Semestral.",
                "Imposto sobre Registos de Serviços."
            ],
            "resposta": "Imposto sobre o Rendimento das Pessoas Singulares.",
            "explicacao": "O IRS incide sobre rendimentos das pessoas singulares, como salários, pensões ou trabalho independente."
        },
        {
            "pergunta": "Porque é importante comunicar o agregado familiar no Portal das Finanças?",
            "opcoes": [
                "Porque essa informação pode influenciar a declaração de IRS.",
                "Porque aumenta automaticamente o salário.",
                "Porque elimina sempre a obrigação de entregar IRS.",
                "Porque substitui todas as faturas."
            ],
            "resposta": "Porque essa informação pode influenciar a declaração de IRS.",
            "explicacao": "A composição do agregado familiar é relevante para efeitos fiscais, nomeadamente no IRS."
        },
        {
            "pergunta": "O que é o IMI?",
            "opcoes": [
                "Imposto Municipal sobre Imóveis.",
                "Imposto Mensal Individual.",
                "Imposto Monetário Internacional.",
                "Imposto Municipal sobre Investimentos."
            ],
            "resposta": "Imposto Municipal sobre Imóveis.",
            "explicacao": "O IMI é um imposto municipal associado aos imóveis."
        },
        {
            "pergunta": "Onde se pode consultar, normalmente, o valor a pagar de IMI?",
            "opcoes": [
                "No Portal das Finanças.",
                "Apenas no banco.",
                "Apenas numa escola.",
                "Exclusivamente por telefone."
            ],
            "resposta": "No Portal das Finanças.",
            "explicacao": "O Portal das Finanças permite consultar informação fiscal, incluindo notas de cobrança e referências de pagamento."
        },
        {
            "pergunta": "Quando alguém passa recibos verdes, que imposto pode ter de considerar além do IRS?",
            "opcoes": [
                "IVA, dependendo do seu enquadramento fiscal.",
                "Apenas IMI.",
                "Apenas IUC.",
                "Nenhum imposto."
            ],
            "resposta": "IVA, dependendo do seu enquadramento fiscal.",
            "explicacao": "Quem trabalha de forma independente pode ter obrigações relacionadas com IVA, dependendo do regime em que está enquadrado."
        },
        {
            "pergunta": "Para que servem os anexos da declaração de IRS?",
            "opcoes": [
                "Para declarar diferentes tipos de rendimentos ou situações fiscais.",
                "Para substituir a senha do Portal das Finanças.",
                "Para eliminar automaticamente dívidas fiscais.",
                "Para servir apenas como comprovativo visual."
            ],
            "resposta": "Para declarar diferentes tipos de rendimentos ou situações fiscais.",
            "explicacao": "Os anexos permitem declarar diferentes categorias de rendimento ou situações específicas."
        },
        {
            "pergunta": "Se uma pessoa residente em Portugal tiver rendimentos obtidos no estrangeiro, o que deve fazer em regra?",
            "opcoes": [
                "Declarar esses rendimentos em Portugal, quando aplicável.",
                "Ignorar sempre esses rendimentos.",
                "Declarar apenas se forem pagos em dinheiro.",
                "Declarar apenas se forem inferiores a 100€."
            ],
            "resposta": "Declarar esses rendimentos em Portugal, quando aplicável.",
            "explicacao": "Os residentes fiscais em Portugal podem ter de declarar rendimentos obtidos em Portugal e no estrangeiro."
        },
        {
            "pergunta": "Porque é importante validar faturas?",
            "opcoes": [
                "Porque algumas despesas podem ser relevantes para deduções no IRS.",
                "Porque todas as faturas eliminam automaticamente o imposto a pagar.",
                "Porque substituem o cartão de cidadão.",
                "Porque evitam sempre a entrega da declaração de IRS."
            ],
            "resposta": "Porque algumas despesas podem ser relevantes para deduções no IRS.",
            "explicacao": "A validação de faturas pode ajudar a garantir que certas despesas são consideradas para efeitos fiscais."
        }
    ]
}


for tema, perguntas in quizzes_por_tema.items():
    with st.expander(f"📦 {tema}", expanded=False):
        st.markdown(f"### Quiz sobre {tema}")

        st.write(
            "Responde às perguntas e submete o quiz para veres a tua pontuação."
        )

        with st.form(f"quiz_form_{tema}"):
            respostas_utilizador = []

            for index, pergunta in enumerate(perguntas):
                st.markdown(
                    f"**{index + 1}. {pergunta['pergunta']}**"
                )

                resposta = st.radio(
                    "Escolhe uma opção:",
                    pergunta["opcoes"],
                    key=f"quiz_{tema}_{index}"
                )

                respostas_utilizador.append(resposta)

                st.write("")

            submitted_quiz = st.form_submit_button(
                f"Submeter quiz - {tema}",
                use_container_width=True
            )

        if submitted_quiz:
            pontuacao = 0

            st.subheader("Resultado do quiz")

            for index, pergunta in enumerate(perguntas):
                resposta_utilizador = respostas_utilizador[index]
                resposta_correta = pergunta["resposta"]

                if resposta_utilizador == resposta_correta:
                    pontuacao += 1

                    st.success(
                        f"{index + 1}. Correto ✅"
                    )

                else:
                    st.error(
                        f"{index + 1}. Incorreto ❌"
                    )

                    st.write(
                        f"**A resposta correta era:** {resposta_correta}"
                    )

                st.caption(
                    pergunta["explicacao"]
                )

                st.divider()

            total_perguntas = len(perguntas)

            percentagem = (
                pontuacao
                / total_perguntas
            ) * 100

            st.metric(
                "Pontuação final",
                f"{pontuacao}/{total_perguntas}",
                f"{percentagem:.0f}%"
            )

            if percentagem >= 80:
                st.success(
                    "Excelente resultado! Demonstraste bons conhecimentos sobre este tema."
                )

            elif percentagem >= 50:
                st.info(
                    "Bom esforço. Revê alguns conteúdos e tenta novamente."
                )

            else:
                st.warning(
                    "Ainda tens alguns conceitos para rever. Volta aos vídeos deste tema e tenta novamente."
                )