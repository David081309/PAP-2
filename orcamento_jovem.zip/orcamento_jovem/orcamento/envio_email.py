import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


SENDER_EMAIL = "andreventuraoriginal@gmail.com"
SENDER_PASSWORD = "sapa mncy vbpe zylc"
RECEIVER_EMAIL = "andreventuraoriginal@gmail.com"


def enviar_email(nome, email_utilizador, assunto, mensagem):
    """
    Envia a mensagem do formulário de contactos
    para o email responsável pela aplicação.
    """

    msg = MIMEMultipart()

    msg["From"] = SENDER_EMAIL
    msg["To"] = RECEIVER_EMAIL
    msg["Subject"] = assunto

    # Permite responder diretamente ao email
    # introduzido pelo utilizador.
    msg["Reply-To"] = email_utilizador

    body = f"""
Nova mensagem recebida através da aplicação Orçamento Jovem.

Nome:
{nome}

Email:
{email_utilizador}

Assunto:
{assunto}

Mensagem:
{mensagem}
    """

    msg.attach(
        MIMEText(
            body,
            "plain",
            "utf-8"
        )
    )

    server = None

    try:
        server = smtplib.SMTP(
            "smtp.gmail.com",
            587,
            timeout=20
        )

        server.starttls()

        server.login(
            SENDER_EMAIL,
            SENDER_PASSWORD
        )

        server.sendmail(
            SENDER_EMAIL,
            RECEIVER_EMAIL,
            msg.as_string()
        )

        return True, "E-mail enviado com sucesso!"

    except smtplib.SMTPAuthenticationError:
        return (
            False,
            "Erro de autenticação. Confirma o email e a password de aplicação."
        )

    except smtplib.SMTPException as erro:
        print(f"Erro SMTP: {erro}")

        return (
            False,
            "Não foi possível enviar o e-mail."
        )

    except Exception as erro:
        print(f"Erro inesperado: {erro}")

        return (
            False,
            "Ocorreu um erro inesperado durante o envio."
        )

    finally:
        if server is not None:
            try:
                server.quit()
            except Exception:
                pass