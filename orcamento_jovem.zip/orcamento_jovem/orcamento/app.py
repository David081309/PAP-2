import streamlit as st
from db import init_db, get_incomes, get_expenses, get_goals
from auth import init_session, login_user, register_user, sidebar_user
from utils import calculate_summary, monthly_savings, active_goal_info
from pages.Alertas import notification_bell

# ─────────────────────────────────────────────
# CONFIGURAÇÃO DA PÁGINA
# ─────────────────────────────────────────────

st.set_page_config(
    page_title="MoneyPath",
    page_icon="💸",
    layout="wide",
    initial_sidebar_state="expanded"
)

def hide_sidebar_when_logged_out():
    st.markdown(
        """
        <style>
        [data-testid="stSidebar"] {
            display: none;
        }

        [data-testid="stSidebarCollapsedControl"] {
            display: none;
        }

        [data-testid="collapsedControl"] {
            display: none;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

# ─────────────────────────────────────────────
# INICIALIZAÇÃO
# ─────────────────────────────────────────────


init_db()
init_session()

if not st.session_state.get("logged_in", False):
    hide_sidebar_when_logged_out()


# ─────────────────────────────────────────────
# UTILIZADOR NÃO AUTENTICADO
# ─────────────────────────────────────────────

if not st.session_state.logged_in:
    st.title("💸 MoneyPath")
    st.caption("Gestão orçamental e educação financeira para iniciantes")

    tab_login, tab_registo = st.tabs(["Login", "Registo"])

# ─────────────────────────────────────────
# TAB LOGIN
# ─────────────────────────────────────────

    with tab_login:

        st.subheader("Entrar")

        with st.form("login_form"):
            username = st.text_input("Nome do utilizador")
            password = st.text_input("Palavra-passe", type="password")
            login_btn = st.form_submit_button("Entrar")

            if login_btn:
                if not username or not password:
                    st.warning("Preenche todos os campos.")

                else:
                    success, message = login_user(username, password)

                    if success:
                        st.success(message)
                        st.rerun()

                    else:
                        st.error(message)

# ─────────────────────────────────────────
# TAB REGISTO
# ─────────────────────────────────────────

    with tab_registo:

        st.subheader("Criar conta")

        with st.form("register_form"):
            new_username = st.text_input("Novo nome de utilizador")

            new_email = st.text_input("Email")

            new_password = st.text_input(
                "Nova palavra-passe",
                type="password"
            )

            confirm_password = st.text_input(
                "Confirmar palavra-passe",
                type="password"
            )

            register_btn = st.form_submit_button("Criar conta")

            if register_btn:
                success, message = register_user(
                    new_username,
                    new_email,
                    new_password,
                    confirm_password
                )

                if success:
                    st.success(message)

                    st.session_state.pending_verification_email = new_email.strip()

                    st.switch_page("pages/Verificacao.py")

                else:
                    st.error(message)


    st.stop()
# ─────────────────────────────────────────────
# UTILIZADOR AUTENTICADO
# ─────────────────────────────────────────────

sidebar_user()

title_col, bell_col = st.columns(

    [8,1],
    vertical_alignment="center"

)

with title_col:
    st.title("💸 MoneyPath")
    st.caption(
        "Gestão orçamental e educação financeira para jovens"
    )

with bell_col:
    notification_bell(
        st.session_state.user_id
    )

st.success(
    f"Sessão iniciada como "
    f"{st.session_state.username}"
)

# ─────────────────────────────────────────────
# CARREGAR DADOS DO UTILIZADOR
# ─────────────────────────────────────────────

user_id = st.session_state.user_id

incomes_df = get_incomes(user_id)

expenses_df = get_expenses(user_id)

goals_df = get_goals(user_id)

# ─────────────────────────────────────────────
# CÁLCULOS
# ─────────────────────────────────────────────

total_incomes, total_expenses, balance = calculate_summary(incomes_df, expenses_df)

month_save = monthly_savings(incomes_df, expenses_df)

if month_save is None:

    month_save = 0.0

goal_title, goal_percent = active_goal_info(goals_df)

# ─────────────────────────────────────────────
# CONTEÚDO PRIVADO
# ─────────────────────────────────────────────

with st.container():

    col1, col2 = st.columns([1.4, 1], gap="large")

    with col1:
        st.subheader("Controla melhor o teu dinheiro, passo a passo")

        st.write(
            "Esta aplicão ajuda-te a registar despesas e vencimentos, "
            "Acompanhar metas e aprender a tomar melhores "
            "Decisões financeiras."
        )

        c1, c2, c3 = st.columns(3)

        c1.metric("Saldo atual", f"{balance:.2f} €")

        c2.metric("Poupança do mês", f"{month_save:.2f} €")

        c3.metric("Meta ativa", f"{goal_percent}%")

    with col2:
        st.info(
            "Usa o menu lateral para aceder às diferentes  "
            "funcionalidades da aplicação."
        )

        if goal_title != "Sem meta":
            st.success(f"Meta atual {goal_title}.")
        else:
            st.warning("Ainda não tens uma meta de poupança.")

st.divider()

st.subheader("Áreas principais")

col1, col2, col3, col4 = st.columns(
    4,
    gap="large"
)

with col1:
    st.markdown("### 📊 Dashboard")
    st.write(
        "Consulta o resumo das receitas, despesas e saldo."
    )

with col2:
    st.markdown("### 💸 Registos")
    st.write(
        "Adiciona receitas e despesas."
    )

with col3:
    st.markdown("### 🎯 Metas")
    st.write(
        "Cria e acompanha objetivos de poupança."
    )

with col4:
    st.markdown("### 📚 Educação")
    st.write(
        "Aprende conceitos importantes de educação financeira."
    )
