import streamlit as st
from streamlit_local_storage import LocalStorage
from email_service import send_verification_email

from db import (
    create_user,
    get_user,
    create_remember_token,
    get_user_by_token,
    clear_remember_token
)


localS = LocalStorage()


# ─────────────────────────────────────────────
# INICIAR SESSÃO / RECUPERAR SESSÃO
# ─────────────────────────────────────────────

def init_session():
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False

    if "user_id" not in st.session_state:
        st.session_state.user_id = None

    if "username" not in st.session_state:
        st.session_state.username = None

    # Se ainda não estiver autenticado, tenta recuperar pelo localStorage
    if not st.session_state.logged_in:
        token = localS.getItem("remember_token")

        if token:
            user = get_user_by_token(token)

            if user is not None:
                st.session_state.logged_in = True
                st.session_state.user_id = user[0]
                st.session_state.username = user[1]


# ─────────────────────────────────────────────
# OBRIGAR LOGIN NAS PÁGINAS PRIVADAS
# ─────────────────────────────────────────────

def require_login():
    init_session()

    if not st.session_state.logged_in:
        st.warning("Tens de iniciar sessão primeiro.")
        st.stop()


# ─────────────────────────────────────────────
# SIDEBAR DO UTILIZADOR
# ─────────────────────────────────────────────

def sidebar_user():
    init_session()

    # Sem login, a função termina aqui.
    # Não cria qualquer conteúdo na sidebar.
    if not st.session_state.logged_in:
        return

    st.sidebar.success(
        f"Sessão iniciada: {st.session_state.username}"
    )

    st.sidebar.title("Navegação")

    st.sidebar.page_link(
        "app.py",
        label="Página principal",
        icon="🏠"
    )

    st.sidebar.page_link(
        "pages/Registos.py",
        label="Registos",
        icon="💸"
    )

    st.sidebar.page_link(
        "pages/Metas.py",
        label="Metas",
        icon="🎯"
    )

    st.sidebar.page_link(
        "pages/Quiz.py",
        label="Quiz",
        icon="📝"
    )

    st.sidebar.page_link(
        "pages/Dashboard.py",
        label="Dashboard",
        icon="📊"
    )

    st.sidebar.page_link(
        "pages/Simulador.py",
        label="Simulador",
        icon="🧮"
    )

    st.sidebar.page_link(
        "pages/Educacao_financeira.py",
        label="Educação financeira",
        icon="📚"
    )

    st.sidebar.page_link(
        "pages/Contactos.py",
        label="Contactos",
        icon="✉️"
    )

    st.sidebar.divider()

    if st.sidebar.button(
        "Terminar sessão",
        use_container_width=True
    ):
        logout_user()
        st.switch_page("app.py")

# ─────────────────────────────────────────────
# LOGIN
# ─────────────────────────────────────────────

def login_user(username, password, remember=False):
    username = username.strip()

    if username == "" or password == "":
        return False, "Preenche o nome de utilizador e a palavra-passe."

    user = get_user(username, password)

    if user == "not_verified":
        return (
            False,
            "A tua conta ainda não foi verificada. "
            "Confirma o token enviado para o teu email."
        )

    if user is None:
        return False, "Nome de utilizador ou palavra-passe incorretos."

    user_id, username = user

    st.session_state.logged_in = True
    st.session_state.user_id = user_id
    st.session_state.username = username

    if remember:
        token = create_remember_token(user_id)

        try:
            localS.setItem("remember_token", token)
        except Exception as error:
            print(f"Erro ao guardar token no localStorage: {error}")

    return True, "Login efetuado com sucesso."


# ─────────────────────────────────────────────
# LOGOUT
# ─────────────────────────────────────────────

def logout_user():
    user_id = st.session_state.get("user_id")

    # Apaga o token da base de dados
    if user_id is not None:
        clear_remember_token(user_id)

    # Tenta apagar o token do localStorage apenas se existir
    try:
        token = localS.getItem("remember_token")

        if token is not None:
            localS.deleteItem("remember_token")

    except KeyError:
        # O token já não existia, por isso não é necessário fazer nada
        pass

    # Limpa a sessão do Streamlit
    st.session_state.logged_in = False
    st.session_state.user_id = None
    st.session_state.username = None


# ─────────────────────────────────────────────
# REGISTO
# ─────────────────────────────────────────────

def register_user(username, email, password, confirm_password):
    username = username.strip()
    email = email.strip()

    if not username or not email or not password or not confirm_password:
        return False, "Preenche todos os campos."

    if password != confirm_password:
        return False, "As palavras-passe não coincidem."

    if len(password) < 4:
        return False, "A palavra-passe deve ter pelo menos 4 caracteres."

    created, token = create_user(
        username,
        email,
        password
    )

    if not created:
        return False, "Esse nome de utilizador ou email já existe."

    try:
        send_verification_email(
            email,
            token
        )

    except Exception as error:
        print(f"Erro ao enviar email: {error}")

        return (
            False,
            "A conta foi criada, mas não foi possível enviar o email de verificação."
        )

    st.session_state.pending_verification_email = email

    return (
        True,
        "Conta criada com sucesso. Foi enviado um token para o teu email."
    )