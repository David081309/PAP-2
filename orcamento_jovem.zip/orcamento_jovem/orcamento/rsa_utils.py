import base64
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding


PRIVATE_KEY_FILE = Path("private_key.pem")
PUBLIC_KEY_FILE = Path("public_key.pem")


def load_public_key():
    if not PUBLIC_KEY_FILE.exists():
        raise FileNotFoundError(
            "A chave pública não foi encontrada. "
            "Executa primeiro generate_rsa_keys.py."
        )

    return serialization.load_pem_public_key(
        PUBLIC_KEY_FILE.read_bytes()
    )


def load_private_key():
    if not PRIVATE_KEY_FILE.exists():
        raise FileNotFoundError(
            "A chave privada não foi encontrada. "
            "Executa primeiro generate_rsa_keys.py."
        )

    return serialization.load_pem_private_key(
        PRIVATE_KEY_FILE.read_bytes(),
        password=None
    )


def encrypt_password(password: str) -> str:
    if not password:
        raise ValueError("A palavra-passe não pode estar vazia.")

    public_key = load_public_key()

    encrypted_password = public_key.encrypt(
        password.encode("utf-8"),
        padding.OAEP(
            mgf=padding.MGF1(
                algorithm=hashes.SHA256()
            ),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

    # O MySQL guarda texto, por isso convertemos
    # os bytes encriptados para Base64.
    return base64.b64encode(
        encrypted_password
    ).decode("utf-8")


def decrypt_password(encrypted_password: str) -> str:
    if not encrypted_password:
        raise ValueError(
            "A palavra-passe encriptada está vazia."
        )

    private_key = load_private_key()

    encrypted_bytes = base64.b64decode(
        encrypted_password.encode("utf-8")
    )

    decrypted_password = private_key.decrypt(
        encrypted_bytes,
        padding.OAEP(
            mgf=padding.MGF1(
                algorithm=hashes.SHA256()
            ),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

    return decrypted_password.decode("utf-8")