from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


PRIVATE_KEY_FILE = Path("private_key.pem")
PUBLIC_KEY_FILE = Path("public_key.pem")


def generate_rsa_keys():
    if PRIVATE_KEY_FILE.exists() or PUBLIC_KEY_FILE.exists():
        print("As chaves RSA já existem.")
        return

    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )

    public_key = private_key.public_key()

    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    PRIVATE_KEY_FILE.write_bytes(private_pem)
    PUBLIC_KEY_FILE.write_bytes(public_pem)

    print("Chaves RSA criadas com sucesso.")


if __name__ == "__main__":
    generate_rsa_keys()