import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import streamlit as st


def send_verification_email(receiver_email, token):
    sender_email = st.secrets["EMAIL_SENDER"]
    password = st.secrets["EMAIL_PASSWORD"]

    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Subject"] = "Token de verificação - Orçamento Jovem"

    body = f"""
O teu token de verificação é:

{token}

Introduz este token na aplicação para ativar a tua conta.

Cumprimentos,
Equipa Orçamento Jovem
"""

    msg.attach(
        MIMEText(body, "plain")
    )

    server = smtplib.SMTP(
        "smtp.gmail.com",
        587
    )

    server.starttls()
    server.login(
        sender_email,
        password
    )

    server.sendmail(
        sender_email,
        receiver_email,
        msg.as_string()
    )

    server.quit()