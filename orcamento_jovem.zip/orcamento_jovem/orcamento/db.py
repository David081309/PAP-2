import mysql.connector
import pandas as pd
import calendar
from datetime import date, datetime, timedelta
import secrets
from rsa_utils import encrypt_password, decrypt_password
import hmac
import secrets


DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "PAProjeto30"


# ─────────────────────────────────────────────
# INICIALIZAR BASE DE DADOS
# ─────────────────────────────────────────────

def init_db():
    cnx = mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD
    )

    cur = cnx.cursor()

    cur.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
    cnx.commit()

    cnx.database = DB_NAME

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            password TEXT NOT NULL,
            remember_token VARCHAR(255),
            token_expiry DATETIME,
            email VARCHAR(255) UNIQUE,
            verification_token VARCHAR(20),
            verification_expiry DATETIME,
            is_verified TINYINT NOT NULL DEFAULT 0
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS incomes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            description VARCHAR(255) NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            income_date DATE NOT NULL,
            is_recurring TINYINT NOT NULL DEFAULT 0,
            frequency VARCHAR(50),
            next_date DATE,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            description VARCHAR(255) NOT NULL,
            category VARCHAR(100) NOT NULL,
            kind VARCHAR(100) NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            expense_date DATE NOT NULL,
            is_recurring TINYINT NOT NULL DEFAULT 0,
            frequency VARCHAR(50),
            next_date DATE,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS goals (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            target_amount DECIMAL(10,2) NOT NULL,
            saved_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            deadline DATE,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cnx.commit()
    cur.close()
    cnx.close()


# Mantém também este nome, caso queiras usar como no exemplo que enviaste
def inicializar_bd():
    init_db()


# ─────────────────────────────────────────────
# LIGAÇÃO À BASE DE DADOS
# ─────────────────────────────────────────────

def get_connection():
    cnx = mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

    return cnx


# ─────────────────────────────────────────────
# DATA SEGUINTE DAS RECORRÊNCIAS
# ─────────────────────────────────────────────

def calculate_next_date(current_date, frequency):
    if isinstance(current_date, datetime):
        current_date = current_date.date()

    if isinstance(current_date, str):
        current_date = date.fromisoformat(current_date)

    if frequency == "Semanal":
        return current_date + timedelta(days=7)

    if frequency == "Mensal":
        if current_date.month == 12:
            next_year = current_date.year + 1
            next_month = 1
        else:
            next_year = current_date.year
            next_month = current_date.month + 1

        last_day = calendar.monthrange(
            next_year,
            next_month
        )[1]

        next_day = min(
            current_date.day,
            last_day
        )

        return date(
            next_year,
            next_month,
            next_day
        )

    if frequency == "Anual":
        next_year = current_date.year + 1

        last_day = calendar.monthrange(
            next_year,
            current_date.month
        )[1]

        next_day = min(
            current_date.day,
            last_day
        )

        return date(
            next_year,
            current_date.month,
            next_day
        )

    return None


# ─────────────────────────────────────────────
# UTILIZADORES
# ─────────────────────────────────────────────

def create_user(username, email, password):
    cnx = get_connection()
    cur = cnx.cursor()

    try:
        token = secrets.token_hex(4)
        expiry = datetime.now() + timedelta(minutes=10)

        encrypted_password = encrypt_password(password)

        cur.execute(
            """
            INSERT INTO users (
                username,
                email,
                password,
                verification_token,
                verification_expiry,
                is_verified
            )
            VALUES (%s, %s, %s, %s, %s, 0)
            """,
            (
                username,
                email,
                encrypted_password,
                token,
                expiry
            )
        )

        cnx.commit()

        return True, token

    except mysql.connector.IntegrityError:
        cnx.rollback()
        return False, None

    except Exception as error:
        cnx.rollback()
        print(f"Erro ao criar utilizador: {error}")
        return False, None

    finally:
        cur.close()
        cnx.close()


def get_user(username, password):
    cnx = get_connection()
    cur = cnx.cursor()

    try:
        cur.execute(
            """
            SELECT id, username, password, is_verified
            FROM users
            WHERE username = %s
            """,
            (username,)
        )

        user = cur.fetchone()

        if user is None:
            return None

        user_id = user[0]
        stored_username = user[1]
        encrypted_password = user[2]

        try:
            decrypted_password = decrypt_password(
                encrypted_password
            )

        except Exception as error:
            print(
                "Erro ao desencriptar a palavra-passe:",
                error
            )
            return None

        if decrypted_password == password:
            return (
                user_id,
                stored_username
            )

        return None

    except mysql.connector.Error as error:
        print(f"Erro ao procurar utilizador: {error}")
        return None

    finally:
        cur.close()
        cnx.close()


def user_exists(username):
    cnx = get_connection()
    cur = cnx.cursor()

    cur.execute(
        """
        SELECT id
        FROM users
        WHERE username = %s
        """,
        (username,)
    )

    user = cur.fetchone()

    cur.close()
    cnx.close()

    return user is not None

def verify_user_token(email, token_input):
    cnx = get_connection()
    cur = cnx.cursor(dictionary=True)

    try:
        cur.execute(
            """
            SELECT
                id,
                verification_token,
                verification_expiry,
                is_verified
            FROM users
            WHERE email = %s
            """,
            (email,)
        )

        user = cur.fetchone()

        if user is None:
            return False, "Conta não encontrada."

        if int(user["is_verified"]) == 1:
            return False, "Esta conta já está verificada."

        token_db = str(
            user["verification_token"]
        ).strip().lower()

        token_input = str(
            token_input
        ).strip().lower()

        expiry = user["verification_expiry"]

        if expiry is not None and expiry < datetime.now():
            return False, "O token expirou. Faz novo registo ou pede novo token."

        if not hmac.compare_digest(token_db, token_input):
            return False, "Token incorreto."

        cur.execute(
            """
            UPDATE users
            SET is_verified = 1,
                verification_token = NULL,
                verification_expiry = NULL
            WHERE id = %s
            """,
            (int(user["id"]),)
        )

        cnx.commit()

        return True, "Conta verificada com sucesso. Já podes fazer login."

    except mysql.connector.Error as error:
        cnx.rollback()
        print(f"Erro ao verificar token: {error}")
        return False, "Erro ao verificar a conta."

    finally:
        cur.close()
        cnx.close()


# ─────────────────────────────────────────────
# TOKEN PARA MANTER LOGIN
# ─────────────────────────────────────────────

def create_remember_token(user_id):
    cnx = get_connection()
    cur = cnx.cursor()

    token = secrets.token_urlsafe(32)
    expiry = datetime.now() + timedelta(days=7)

    cur.execute(
        """
        UPDATE users
        SET remember_token = %s,
            token_expiry = %s
        WHERE id = %s
        """,
        (
            token,
            expiry,
            int(user_id)
        )
    )

    cnx.commit()
    cur.close()
    cnx.close()

    return token


def get_user_by_token(token):
    if not token:
        return None

    cnx = get_connection()
    cur = cnx.cursor()

    cur.execute(
        """
        SELECT id, username
        FROM users
        WHERE remember_token = %s
        AND token_expiry > NOW()
        """,
        (token,)
    )

    user = cur.fetchone()

    cur.close()
    cnx.close()

    return user


def clear_remember_token(user_id):
    cnx = get_connection()
    cur = cnx.cursor()

    cur.execute(
        """
        UPDATE users
        SET remember_token = NULL,
            token_expiry = NULL
        WHERE id = %s
        """,
        (int(user_id),)
    )

    cnx.commit()
    cur.close()
    cnx.close()


# ─────────────────────────────────────────────
# RECEITAS
# ─────────────────────────────────────────────

def add_income(
    user_id,
    description,
    amount,
    income_date,
    is_recurring=0,
    frequency=None
):
    income_date = date.fromisoformat(
        str(income_date)
    )

    next_date = None

    if int(is_recurring) == 1 and frequency:
        next_date = calculate_next_date(
            income_date,
            frequency
        )

    cnx = get_connection()
    cur = cnx.cursor()

    try:
        cur.execute(
            """
            INSERT INTO incomes (
                user_id,
                description,
                amount,
                income_date,
                is_recurring,
                frequency,
                next_date
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (
                int(user_id),
                description,
                float(amount),
                income_date,
                int(is_recurring),
                frequency,
                next_date
            )
        )

        cnx.commit()

    finally:
        cur.close()
        cnx.close()


def get_incomes(user_id):
    cnx = get_connection()

    try:
        return pd.read_sql_query(
            """
            SELECT *
            FROM incomes
            WHERE user_id = %s
            ORDER BY income_date DESC, id DESC
            """,
            cnx,
            params=(int(user_id),)
        )

    finally:
        cnx.close()


def delete_income(record_id, user_id):
    cnx = get_connection()
    cur = cnx.cursor()

    try:
        cur.execute(
            """
            DELETE FROM incomes
            WHERE id = %s
            AND user_id = %s
            """,
            (
                int(record_id),
                int(user_id)
            )
        )

        cnx.commit()
        return cur.rowcount > 0

    finally:
        cur.close()
        cnx.close()


# ─────────────────────────────────────────────
# DESPESAS
# ─────────────────────────────────────────────

def add_expense(
    user_id,
    description,
    category,
    kind,
    amount,
    expense_date,
    is_recurring=0,
    frequency=None
):
    expense_date = date.fromisoformat(
        str(expense_date)
    )

    next_date = None

    if int(is_recurring) == 1 and frequency:
        next_date = calculate_next_date(
            expense_date,
            frequency
        )

    cnx = get_connection()
    cur = cnx.cursor()

    try:
        cur.execute(
            """
            INSERT INTO expenses (
                user_id,
                description,
                category,
                kind,
                amount,
                expense_date,
                is_recurring,
                frequency,
                next_date
            )
            VALUES (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s
            )
            """,
            (
                int(user_id),
                description,
                category,
                kind,
                float(amount),
                expense_date,
                int(is_recurring),
                frequency,
                next_date
            )
        )

        cnx.commit()

    finally:
        cur.close()
        cnx.close()


def get_expenses(user_id):
    cnx = get_connection()

    try:
        return pd.read_sql_query(
            """
            SELECT *
            FROM expenses
            WHERE user_id = %s
            ORDER BY expense_date DESC, id DESC
            """,
            cnx,
            params=(int(user_id),)
        )

    finally:
        cnx.close()


def delete_expense(record_id, user_id):
    cnx = get_connection()
    cur = cnx.cursor()

    try:
        cur.execute(
            """
            DELETE FROM expenses
            WHERE id = %s
            AND user_id = %s
            """,
            (
                int(record_id),
                int(user_id)
            )
        )

        cnx.commit()
        return cur.rowcount > 0

    finally:
        cur.close()
        cnx.close()


# ─────────────────────────────────────────────
# METAS DE POUPANÇA
# ─────────────────────────────────────────────

def add_goal(
    user_id,
    title,
    target_amount,
    saved_amount,
    deadline
):
    cnx = get_connection()
    cur = cnx.cursor()

    try:
        cur.execute(
            """
            INSERT INTO goals (
                user_id,
                title,
                target_amount,
                saved_amount,
                deadline
            )
            VALUES (%s, %s, %s, %s, %s)
            """,
            (
                int(user_id),
                title,
                float(target_amount),
                float(saved_amount),
                str(deadline)
            )
        )

        cnx.commit()

    finally:
        cur.close()
        cnx.close()


def get_goals(user_id):
    cnx = get_connection()

    try:
        return pd.read_sql_query(
            """
            SELECT *
            FROM goals
            WHERE user_id = %s
            ORDER BY id DESC
            """,
            cnx,
            params=(int(user_id),)
        )

    finally:
        cnx.close()


def update_goal_saved_amount(
    user_id,
    goal_id,
    amount_change
):
    cnx = get_connection()
    cur = cnx.cursor(dictionary=True)

    try:
        cur.execute(
            """
            SELECT target_amount, saved_amount
            FROM goals
            WHERE id = %s
            AND user_id = %s
            FOR UPDATE
            """,
            (
                int(goal_id),
                int(user_id)
            )
        )

        goal = cur.fetchone()

        if goal is None:
            cnx.rollback()
            return False, "Meta não encontrada."

        target = float(
            goal["target_amount"]
        )

        saved = float(
            goal["saved_amount"]
        )

        amount_change = float(
            amount_change
        )

        new_saved_amount = round(
            saved + amount_change,
            2
        )

        if amount_change == 0:
            cnx.rollback()

            return (
                False,
                "Indica um valor diferente de zero."
            )

        if new_saved_amount < 0:
            cnx.rollback()

            return (
                False,
                f"Não podes retirar "
                f"{abs(amount_change):.2f}€. "
                f"Tens apenas {saved:.2f}€ poupados."
            )

        if new_saved_amount > target:
            remaining = max(
                0.0,
                target - saved
            )

            cnx.rollback()

            return (
                False,
                f"Não podes adicionar "
                f"{amount_change:.2f}€. "
                f"O máximo permitido é "
                f"{remaining:.2f}€."
            )

        cur.execute(
            """
            UPDATE goals
            SET saved_amount = %s
            WHERE id = %s
            AND user_id = %s
            """,
            (
                new_saved_amount,
                int(goal_id),
                int(user_id)
            )
        )

        cnx.commit()

        if amount_change > 0:
            return (
                True,
                f"Foram adicionados "
                f"{amount_change:.2f}€ à meta."
            )

        return (
            True,
            f"Foram retirados "
            f"{abs(amount_change):.2f}€ da meta."
        )

    except mysql.connector.Error as error:
        cnx.rollback()

        print(
            f"Erro ao atualizar a meta: {error}"
        )

        return (
            False,
            "Não foi possível atualizar a meta."
        )

    finally:
        cur.close()
        cnx.close()


def delete_goal(goal_id, user_id):
    cnx = get_connection()
    cur = cnx.cursor()

    try:
        cur.execute(
            """
            DELETE FROM goals
            WHERE id = %s
            AND user_id = %s
            """,
            (
                int(goal_id),
                int(user_id)
            )
        )

        cnx.commit()

        return cur.rowcount > 0

    except mysql.connector.Error as error:
        cnx.rollback()

        print(f"Erro ao eliminar meta: {error}")

        return False

    finally:
        cur.close()
        cnx.close()


if __name__ == "__main__":
    print("A iniciar criação da base de dados...")
    init_db()
    print("Base de dados criada/inicializada com sucesso.")